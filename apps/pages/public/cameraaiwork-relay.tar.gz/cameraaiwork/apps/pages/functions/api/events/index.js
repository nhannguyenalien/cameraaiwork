import { getDb } from "../../_lib/db.js";
import { errorJson, json, withErrorHandling } from "../../_lib/http.js";
import { encodeEventCursor, eventWhere, parseEventQuery, validDate } from "../../_lib/events.js";

export const onRequestGet = withErrorHandling(async ({ request, env, data }) => {
  const url = new URL(request.url);
  const { limit, cursor, invalidCursor, filters } = parseEventQuery(url);
  if (invalidCursor) return errorJson("cursor không hợp lệ", 400);
  if ((filters.from && !validDate(filters.from)) || (filters.to && !validDate(filters.to))) {
    return errorJson("from/to phải là thời gian ISO hợp lệ", 400);
  }
  if (filters.from && filters.to && Date.parse(filters.from) > Date.parse(filters.to)) {
    return errorJson("from không được sau to", 400);
  }
  if (filters.acknowledged && !["true", "false"].includes(filters.acknowledged)) {
    return errorJson("acknowledged phải là true hoặc false", 400);
  }
  const { conditions, args } = eventWhere(data.accountId, filters, cursor);

  const db = getDb(env);
  const result = await db.execute({
    sql: `
      SELECT events.*, people.label as person_label
      FROM events
      LEFT JOIN people ON people.id = events.person_id
      WHERE ${conditions.join(" AND ")}
      ORDER BY events.timestamp DESC, events.id DESC LIMIT ?
    `,
    args: [...args, limit + 1],
  });
  const hasMore = result.rows.length > limit;
  const rows = result.rows.slice(0, limit).map((row) => ({ ...row, acknowledged: Boolean(row.acknowledged) }));
  const nextCursor = hasMore ? encodeEventCursor(rows.at(-1)) : null;
  return json(rows, { headers: {
    "X-Next-Cursor": nextCursor || "",
    "X-Has-More": String(hasMore),
    "Access-Control-Expose-Headers": "X-Next-Cursor, X-Has-More",
  } });
});
