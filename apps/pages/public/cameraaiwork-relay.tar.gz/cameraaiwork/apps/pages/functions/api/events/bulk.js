import { getDb } from "../../_lib/db.js";
import { errorJson, json, withErrorHandling } from "../../_lib/http.js";

export const onRequestDelete = withErrorHandling(async ({ request, env, data }) => {
  const body = await request.json().catch(() => null);
  if (!Array.isArray(body?.ids)) return errorJson("ids phải là một mảng", 400);
  const ids = [...new Set(body.ids)].filter((id) => Number.isSafeInteger(Number(id)) && Number(id) > 0).map(Number);
  if (!ids.length || ids.length > 100) return errorJson("ids phải chứa từ 1 đến 100 event hợp lệ", 400);
  const placeholders = ids.map(() => "?").join(",");
  const db = getDb(env);
  const found = await db.execute({
    sql: `SELECT id, image_key, video_key FROM events WHERE account_id = ? AND id IN (${placeholders})`,
    args: [data.accountId, ...ids],
  });
  if (env.EVENTS_BUCKET) {
    const keys = found.rows.flatMap((row) => [row.image_key, row.video_key]).filter(Boolean);
    if (keys.length) await env.EVENTS_BUCKET.delete(keys);
  }
  if (found.rows.length) {
    const ownedIds = found.rows.map((row) => Number(row.id));
    await db.execute({
      sql: `DELETE FROM events WHERE account_id = ? AND id IN (${ownedIds.map(() => "?").join(",")})`,
      args: [data.accountId, ...ownedIds],
    });
  }
  return json({ ok: true, deleted: found.rows.length });
});
