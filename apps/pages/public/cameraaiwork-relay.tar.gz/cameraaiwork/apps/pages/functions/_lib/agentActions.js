export const AGENT_ACTIONS = Object.freeze({
  list_cameras: {
    description: "Liệt kê camera và site thuộc tài khoản",
    readOnly: true,
    parameters: {},
  },
  list_people: {
    description: "Liệt kê người đã nhận diện, kể cả người chưa đặt tên",
    readOnly: true,
    parameters: {},
  },
  list_recent_events: {
    description: "Tìm event gần đây theo thời gian, camera, người hoặc trạng thái",
    readOnly: true,
    parameters: {
      limit: "integer 1..100",
      from: "ISO datetime",
      to: "ISO datetime",
      camera: "camera stream",
      personId: "person id",
      type: "event type",
      acknowledged: "boolean",
    },
  },
  camera_status: {
    description: "Kiểm tra camera/relay online và khả năng PTZ",
    readOnly: true,
    parameters: { siteId: "required", cameraId: "required" },
  },
  camera_config: {
    description: "Đọc cấu hình camera hiện tại từ relay",
    readOnly: true,
    parameters: { siteId: "required", cameraId: "required" },
  },
  get_live_link: {
    description: "Tạo link xem trực tiếp có thời hạn 5 phút",
    readOnly: true,
    parameters: { siteId: "required", cameraId: "required" },
  },
  get_snapshot_link: {
    description: "Trả về API URL để lấy ảnh chụp hiện tại",
    readOnly: true,
    parameters: { siteId: "required", cameraId: "required" },
  },
  label_person: {
    description: "Đặt hoặc xoá tên của một người đã nhận diện",
    readOnly: false,
    parameters: { personId: "required", label: "string or null" },
  },
  set_recording: {
    description: "Bật/tắt lưu clip khi camera phát hiện người",
    readOnly: false,
    parameters: { siteId: "required", cameraId: "required", recordOnPerson: "boolean" },
  },
  move_camera: {
    description: "Điều khiển PTZ, zoom, home hoặc preset",
    readOnly: false,
    parameters: {
      siteId: "required",
      cameraId: "required",
      command: "up|down|left|right|stop|zoomIn|zoomOut|home|gotoPreset|setPreset",
      speed: "number 0.1..1",
      durationMs: "integer 100..5000",
      preset: "preset name/number",
    },
  },
  update_camera_config: {
    description: "Cập nhật cấu hình camera trên relay",
    readOnly: false,
    parameters: { siteId: "required", cameraId: "required", config: "non-empty object" },
  },
});

export function actionCatalog() {
  return Object.entries(AGENT_ACTIONS).map(([name, definition]) => ({ name, ...definition, requiresConfirmation: !definition.readOnly }));
}

function nonEmpty(value) {
  return typeof value === "string" && value.trim().length > 0;
}

export function validateAgentAction(action, args = {}) {
  if (!AGENT_ACTIONS[action]) return `action không hợp lệ. Hỗ trợ: ${Object.keys(AGENT_ACTIONS).join(", ")}`;
  if (!args || typeof args !== "object" || Array.isArray(args)) return "args phải là object";
  const needsCamera = ["camera_status", "camera_config", "get_live_link", "get_snapshot_link", "set_recording", "move_camera", "update_camera_config"].includes(action);
  if (needsCamera && (!nonEmpty(args.siteId) || !nonEmpty(args.cameraId))) return "siteId và cameraId là bắt buộc";
  if (action === "label_person" && !nonEmpty(args.personId)) return "personId là bắt buộc";
  if (action === "label_person" && args.label !== null && typeof args.label !== "string") return "label phải là string hoặc null";
  if (action === "label_person" && typeof args.label === "string" && args.label.length > 100) return "label tối đa 100 ký tự";
  if (action === "set_recording" && typeof args.recordOnPerson !== "boolean") return "recordOnPerson phải là boolean";
  if (action === "move_camera" && !nonEmpty(args.command)) return "command là bắt buộc";
  if (action === "move_camera" && !["up", "down", "left", "right", "stop", "zoomIn", "zoomOut", "home", "gotoPreset", "setPreset"].includes(args.command)) return "command PTZ không hợp lệ";
  if (action === "move_camera" && args.speed !== undefined && (!Number.isFinite(Number(args.speed)) || Number(args.speed) < 0.1 || Number(args.speed) > 1)) return "speed phải từ 0.1 đến 1";
  if (action === "move_camera" && args.durationMs !== undefined && (!Number.isInteger(Number(args.durationMs)) || Number(args.durationMs) < 100 || Number(args.durationMs) > 5000)) return "durationMs phải từ 100 đến 5000";
  if (action === "update_camera_config" && (!args.config || typeof args.config !== "object" || Array.isArray(args.config) || !Object.keys(args.config).length)) return "config phải là object không rỗng";
  return null;
}

export function requiresAgentConfirmation(action) {
  return Boolean(AGENT_ACTIONS[action] && !AGENT_ACTIONS[action].readOnly);
}
