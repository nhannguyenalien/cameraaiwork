import { actionCatalog, requiresAgentConfirmation, validateAgentAction } from "../../_lib/agentActions.js";
import { errorJson, json, withErrorHandling } from "../../_lib/http.js";
import { onRequestGet as listCameras } from "../cameras/index.js";
import { onRequestGet as listPeople } from "../people/index.js";
import { onRequestGet as listEvents } from "../events/index.js";
import { onRequestGet as cameraStatus } from "../cameras/[site]/[camera]/status.js";
import { onRequestGet as cameraConfig, onRequestPut as updateCameraConfig } from "../cameras/[site]/[camera]/config.js";
import { onRequestPost as createLiveLink } from "../cameras/[site]/[camera]/live.js";
import { onRequestPatch as labelPerson } from "../people/[id].js";
import { onRequestPatch as setRecording } from "../cameras/[site]/[camera]/settings.js";
import { onRequestPost as moveCamera } from "../cameras/[site]/[camera]/ptz.js";

export const onRequestGet = withErrorHandling(async () => json({ actions: actionCatalog() }));

function requestWithJson(request, method, body) {
  const headers = new Headers(request.headers);
  headers.set("content-type", "application/json");
  return new Request(request.url, { method, headers, body: JSON.stringify(body) });
}

function eventRequest(request, args) {
  const url = new URL(request.url);
  url.pathname = "/api/events";
  for (const key of ["limit", "from", "to", "camera", "type", "acknowledged"]) {
    if (args[key] !== undefined && args[key] !== null && args[key] !== "") url.searchParams.set(key, String(args[key]));
  }
  if (args.personId) url.searchParams.set("person", String(args.personId));
  return new Request(url, { method: "GET", headers: request.headers });
}

async function execute(action, args, context) {
  const { request, env, data } = context;
  const cameraParams = { site: args.siteId, camera: args.cameraId };
  switch (action) {
    case "list_cameras": return listCameras({ request, env, data, params: {} });
    case "list_people": return listPeople({ request, env, data, params: {} });
    case "list_recent_events": return listEvents({ request: eventRequest(request, args), env, data, params: {} });
    case "camera_status": return cameraStatus({ request, env, data, params: cameraParams });
    case "camera_config": return cameraConfig({ request, env, data, params: cameraParams });
    case "get_live_link": return createLiveLink({ request, env, data, params: cameraParams });
    case "get_snapshot_link": {
      const url = new URL(request.url);
      url.pathname = `/api/cameras/${encodeURIComponent(args.siteId)}/${encodeURIComponent(args.cameraId)}/snapshot`;
      url.search = "";
      return json({ url: url.toString(), authenticationRequired: true });
    }
    case "label_person": return labelPerson({ request: requestWithJson(request, "PATCH", { label: args.label }), env, data, params: { id: args.personId } });
    case "set_recording": return setRecording({ request: requestWithJson(request, "PATCH", { recordOnPerson: args.recordOnPerson }), env, data, params: cameraParams });
    case "move_camera": {
      const { command, siteId: _siteId, cameraId: _cameraId, ...options } = args;
      return moveCamera({ request: requestWithJson(request, "POST", { ...options, action: command }), env, data, params: cameraParams });
    }
    case "update_camera_config": return updateCameraConfig({ request: requestWithJson(request, "PUT", args.config), env, data, params: cameraParams });
    default: return errorJson("action không hợp lệ", 400);
  }
}

export const onRequestPost = withErrorHandling(async (context) => {
  const body = await context.request.json().catch(() => null);
  if (!body) return errorJson("Invalid JSON body", 400);
  const action = typeof body.action === "string" ? body.action.trim() : "";
  const args = body.args ?? {};
  const validationError = validateAgentAction(action, args);
  if (validationError) return errorJson(validationError, 400);

  if (requiresAgentConfirmation(action) && body.confirmed !== true) {
    return json({
      error: "Thao tác này cần xác nhận trước khi thực thi",
      requiresConfirmation: true,
      proposal: { action, args },
    }, { status: 428 });
  }
  return execute(action, args, context);
});
