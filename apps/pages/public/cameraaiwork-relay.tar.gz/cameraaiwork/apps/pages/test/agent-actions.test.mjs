import assert from "node:assert/strict";
import test from "node:test";
import { actionCatalog, requiresAgentConfirmation, validateAgentAction } from "../functions/_lib/agentActions.js";
import { onRequestPost } from "../functions/api/agent/actions.js";

test("agent action catalog identifies read and write operations", () => {
  const catalog = actionCatalog();
  assert.equal(catalog.find((item) => item.name === "camera_status").requiresConfirmation, false);
  assert.equal(catalog.find((item) => item.name === "move_camera").requiresConfirmation, true);
  assert.equal(requiresAgentConfirmation("label_person"), true);
});

test("agent action validation requires scoped camera identifiers", () => {
  assert.equal(validateAgentAction("camera_status", {}), "siteId và cameraId là bắt buộc");
  assert.equal(validateAgentAction("camera_status", { siteId: "site-1", cameraId: "cam-1" }), null);
});

test("agent action validation protects mutating payloads", () => {
  assert.equal(validateAgentAction("set_recording", { siteId: "site-1", cameraId: "cam-1", recordOnPerson: "yes" }), "recordOnPerson phải là boolean");
  assert.equal(validateAgentAction("update_camera_config", { siteId: "site-1", cameraId: "cam-1", config: {} }), "config phải là object không rỗng");
  assert.match(validateAgentAction("delete_everything", {}), /action không hợp lệ/);
});

test("state-changing agent action returns an exact confirmation proposal", async () => {
  const payload = { action: "move_camera", args: { siteId: "site-1", cameraId: "cam-1", command: "left", durationMs: 500 } };
  const response = await onRequestPost({
    request: new Request("https://example.test/api/agent/actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) }),
    env: {}, data: { accountId: "acct-1" }, params: {},
  });
  assert.equal(response.status, 428);
  assert.deepEqual(await response.json(), {
    error: "Thao tác này cần xác nhận trước khi thực thi",
    requiresConfirmation: true,
    proposal: payload,
  });
});
